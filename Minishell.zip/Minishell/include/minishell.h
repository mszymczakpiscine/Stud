/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mszymcza <mszymcza@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 14:54:20 by mszymcza          #+#    #+#             */
/*   Updated: 2025/09/06 17:35:12 by mszymcza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

// librairies standards
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../libft/libft.h"

// librairies readline
#include <readline/history.h>
#include <readline/readline.h>

// librairies parsing 
#include <ctype.h>
#include <sys/wait.h>
#include <sys/types.h>

// librairies redirection 
#include <fcntl.h>

// prototypes des fonctions
char			**token_input(const char *input);
void			execute_command(char	**tokens);
void			run_builtin(char **tokens, int fd);
int				handle_redirection(char	**tokens);
int				is_builtin(char	**tokens);
char			**clean_tokens(char **tokens);
int				redirect_out_trunc(char *file);
int				redirect_out_append(char *file);
int				redirect_in(char *file);

#endif