/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirections.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mszymcza <mszymcza@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/06 14:21:06 by mszymcza          #+#    #+#             */
/*   Updated: 2025/09/06 17:30:41 by mszymcza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

//redireection + pipes

int	redirect_out_trunc(char *file)
{
	int	fd;

	fd = open(file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
	if (fd < 0)
		return (perror("minishell"), -1);
	dup2(fd, STDOUT_FILENO);
	close(fd);
	return (0);
}

int	redirect_out_append(char *file)
{
	int	fd;

	fd = open(file, O_WRONLY | O_CREAT | O_APPEND, 0644);
	if (fd < 0)
		return (perror("minishell"), -1);
	dup2(fd, STDOUT_FILENO);
	close(fd);
	return (0);
}

int	redirect_in(char *file)
{
	int	fd;

	fd = open(file, O_RDONLY);
	if (fd < 0)
		return (perror("minishell"), -1);
	dup2(fd, STDIN_FILENO);
	close(fd);
	return (0);
}

int	handle_redirection(char **tokens)
{
	int	i;

	i = 0;
	while (tokens[i])
	{
		if (!strcmp(tokens[i], ">") && tokens[i + 1])
			redirect_out_trunc(tokens[i + 1]);
		else if (!strcmp(tokens[i], ">>") && tokens[i + 1])
			redirect_out_append(tokens[i + 1]);
		else if (!strcmp(tokens[i], "<") && tokens[i + 1])
			redirect_in(tokens[i + 1]);
		i++;
	}
	return (0);
}

//ft_strcmp