/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtins.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mszymcza <mszymcza@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/06 12:08:09 by mszymcza          #+#    #+#             */
/*   Updated: 2025/09/06 13:37:44 by mszymcza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

// commandes internes au shell
int	is_builtin(char	**tokens)
{
	if(tokens[0] == NULL)
		return (0);
	if (strcmp(tokens[0], "cd") == 0)
		return (1);
	if (strcmp(tokens[0], "exit") == 0)
		return (1);
	if (strcmp(tokens[0], "echo") == 0)
		return (1);
	if (strcmp(tokens[0], "pwd") == 0)
		return (1);
	return (0);
}

void	run_builtin(char **tokens)
{
	if(strcmp(tokens[0], "cd") == 0)
	{
		if(tokens[1] == NULL)
		{
			fprintf(stderr, "minishell: cd : missing arguments\n"); //fprintf a verifier et faire
		}
		else if (chdir(tokens[1]) != 0)
		{
			perror("minishell");
		}
	}
	else if (strcmp(tokens[0], "exit") == 0)
	{
		printf("exit\n");
		exit(0);
	}
	else if (strcmp(tokens[0], "echo") == 0)
	{
		int	i = 1;
		while (tokens[i] != NULL)
		{
			printf("%s", tokens[i]);
			if (tokens[i + 1] != NULL)
				printf(" ");
			i++;
		}
		printf("\n");
	}
	else if (strcmp(tokens[0], "pwd") == 0)
	{
		char	cwd[1024];

		if(getcwd(cwd, sizeof(cwd)) != NULL)
			printf("%s\n", cwd);
		else
			perror("minishell");
	}
}
