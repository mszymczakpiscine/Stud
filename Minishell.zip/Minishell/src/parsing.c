/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mszymcza <mszymcza@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 15:35:39 by mszymcza          #+#    #+#             */
/*   Updated: 2025/09/06 17:04:33 by mszymcza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
//#include "../libft/libft.h"

//separe les mots par des espaces + gestion ls, "", cat etc...
char	**token_input(const char *input)
{
	char	**tokens = malloc(100 * sizeof(char *));
	int		pos = 0;
	int 	i = 0;

	while (input[i] != '\0')
	{
		while (isspace(input[i]))
			i++;
		if (input[i] == 0)
			break;
		char	buffer[1024];
		int		j = 0;

		if (input[i] == '"' || input[i] == '\'')
		{
			char	quote = input[i++];
			while (input[i] != '\0' && input[i] != quote)
			{
				buffer[j++] = input[i++];
			}
			if (input[i] == quote)
				i++;
		}
		else
		{
			while (input[i] != 0 && !isspace(input[i])) //mettre fonction isspace
			{
				buffer[j++] = input[i++];
			}
		}
		buffer[j] = '\0';
		tokens[pos++] = ft_strdup(buffer);
	}
	tokens[pos] = NULL;
	return (tokens);
}

char	**clean_tokens(char **tokens)
{
	char	**result = malloc(100 * sizeof(char *));
	int		i = 0;
	int 	j = 0;

	while (tokens[i])
	{
		if (tokens[i] != NULL)
			result[j++] = tokens[i];
		i++;
	}
	result[j] = NULL;
	return result;
}

void	execute_command(char	**tokens)
{
	if (tokens[0] == NULL)
		return ;
	pid_t	pid = fork();
	if (pid == 0)
	{
		if (handle_redirection(tokens) == -1)
			exit(EXIT_FAILURE);
		char	**args = clean_tokens(tokens);
		if (args[0] != NULL)
		{
			if (execvp(args[0], args) == -1)
			{
				perror("minishell");
				exit(EXIT_FAILURE);
			}
		}
		exit(EXIT_SUCCESS);
	}
	else if (pid > 0)
	{
		int	status;
		waitpid(pid, &status, 0);
	}
	else
	{
		perror("fork");
	}
}

