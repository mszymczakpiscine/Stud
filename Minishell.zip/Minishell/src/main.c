/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mszymcza <mszymcza@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 15:08:18 by mszymcza          #+#    #+#             */
/*   Updated: 2025/09/06 17:02:52 by mszymcza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	main(void)
{
	char	*input;
	char	**tokens;
	int		i;

	while (1)
	{
		input = readline("minishell$ ");
		if (!input)
		{
			printf("exit\n");
			break ;
		}
		if (*input == '\0')
		{
			free(input);
			continue ;
		}
		add_history(input);
		if (strcmp(input, "exit") == 0)
		{
			free(input);
			break ;
		}
		tokens = token_input(input);
		if (!tokens)
		{
			free(input);
			continue ;
		}
		if (is_builtin(tokens))
			run_builtin(tokens);
		else
		{
			/* 🔹 Appel des redirections avant l’exécution */
			if (handle_redirection(tokens) == 0)
				execute_command(tokens);
		}
		i = 0;
		while (tokens[i])
		{
			printf("Token[%d] : %s\n", i, tokens[i]);
			free(tokens[i]);
			i++;
		}
		free(tokens);
		free(input);
	}
	return (0);
}
