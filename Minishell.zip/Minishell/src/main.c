/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mszymcza <mszymcza@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/02 15:08:18 by mszymcza          #+#    #+#             */
/*   Updated: 2025/09/06 18:28:03 by mszymcza         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	main(void)
{
	char	*input;
	char	**tokens;
	int		i;

	while (1)
	{
		input = readline("minishell$ ");
		if (!input)
		{
			printf("exit\n");
			break ;
		}
		if (*input == '\0')
		{
			free(input);
			continue ;
		}
		add_history(input);
		if (strcmp(input, "exit") == 0)
		{
			free(input);
			break ;
		}
		tokens = token_input(input);
		if (!tokens)
		{
			free(input);
			continue ;
		}
		int fd = STDOUT_FILENO;
        for (int j = 0; tokens[j]; j++)
        {
            if (!strcmp(tokens[j], ">") && tokens[j + 1])
            {
                fd = open(tokens[j + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
                break;
            }
            else if (!strcmp(tokens[j], ">>") && tokens[j + 1])
            {
                fd = open(tokens[j + 1], O_WRONLY | O_CREAT | O_APPEND, 0644);
                break;
            }
        }
        char **args = clean_tokens(tokens);
        if (is_builtin(args))
            run_builtin(args, fd);
        else
            execute_command(tokens);
        if (fd != STDOUT_FILENO)
            close(fd);
        i = 0;
        while (tokens[i])
        {
            printf("Token[%d] : %s\n", i, tokens[i]);
            free(tokens[i]);
            i++;
        }
        free(tokens);
        free(args);
        free(input);
	}
	return (0);
}
