/* minishell_checker_full.c
 *
 * Checker complet et précis pour le sujet Minishell (42).
 * - Analyse statique (Makefile, headers, globals, builtins, fonctions autorisées, parsing tokens)
 * - Tests dynamiques (comparaison ./minishell vs bash pour commandes, redirections, pipes, heredoc, expansions, $?).
 *
 * Compile:
 * gcc -std=c11 -Wall -Wextra -O2 -o minishell_checker minishell_checker_full.c
 *
 * Usage:
 * ./minishell_checker   (à lancer depuis la racine du dépôt minishell)
 *
 * Note: ce programme est heuristique — il détecte les motifs et exécute des tests simples.
 */

#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
#include <signal.h>
#include <sys/wait.h>

#define MAXPATH 4096
#define BUF 8192

/* Structure qui suit chaque critère du sujet */
typedef struct {
    /* Makefile */
    int makefile_present;
    int mk_NAME;
    int mk_all;
    int mk_clean;
    int mk_fclean;
    int mk_re;
    int mk_make_n_ok;

    /* Headers */
    int headers_total;
    int headers_with_guards;

    /* Globals */
    int globals_suspected;    /* heuristique : nombre de lignes ressemblant à une var globale */
    int sig_atomic_count;     /* nb d'occurrences de sig_atomic_t non extern */

    /* Builtins (echo, cd, pwd, export, unset, env, exit) */
    int builtin_echo;
    int builtin_cd;
    int builtin_pwd;
    int builtin_export;
    int builtin_unset;
    int builtin_env;
    int builtin_exit;

    /* Fonctions externes / syscalls */
    int uses_readline;
    int uses_rl_functions; /* rl_on_new_line, rl_replace_line ... */
    int uses_fork;
    int uses_execve;
    int uses_pipe;
    int uses_dup2;
    int uses_waitpid;
    int uses_signal; /* signal or sigaction */
    int uses_getcwd;
    int uses_chdir;

    /* Parsing tokens */
    int token_single_quotes;
    int token_double_quotes;
    int token_dollar_var;
    int token_dollar_qm; /* $? */
    int token_redir_input;    /* < */
    int token_redir_output;   /* > */
    int token_redir_append;   /* >> */
    int token_heredoc;        /* << */
    int token_pipe;

} Status;

/* Initialisation */
static Status S;

/* --- Utils fichiers --- */
static char *slurp(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long sz = ftell(f);
    if (sz < 0) { fclose(f); return NULL; }
    rewind(f);
    char *buf = malloc((size_t)sz + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t r = fread(buf, 1, (size_t)sz, f);
    buf[r] = '\0';
    fclose(f);
    return buf;
}

/* Vérifie si Makefile contient les targets et si `make -n` retourne 0 */
static void inspect_makefile(const char *path) {
    char *content = slurp(path);
    if (!content) return;
    S.makefile_present = 1;
    if (strstr(content, "NAME")) S.mk_NAME = 1;
    if (strstr(content, "all:") || strstr(content, "\nall ")) S.mk_all = 1;
    if (strstr(content, "clean:") || strstr(content, "\nclean ")) S.mk_clean = 1;
    if (strstr(content, "fclean:") || strstr(content, "\nfclean ")) S.mk_fclean = 1;
    if (strstr(content, "re:") || strstr(content, "\nre ")) S.mk_re = 1;
    free(content);

    /* test make -n (heuristique) */
    int r = system("make -n >/dev/null 2>&1");
    if (r == 0) S.mk_make_n_ok = 1;
}

/* Heuristique : détecte include guards dans un header (cherche #ifndef et #define) */
static void inspect_header(const char *path) {
    char *content = slurp(path);
    if (!content) return;
    S.headers_total++;
    if (strstr(content, "#ifndef") && strstr(content, "#define")) S.headers_with_guards++;
    free(content);
}

/* Heuristique : scan d'un fichier source pour détecter tokens / fonctions / builtins / globals simples */
static void inspect_source(const char *path) {
    char *content = slurp(path);
    if (!content) return;

    /* Count suspicious global-like lines:
       - lines that contain a semicolon and not inside function prototype heuristics
       Very approximate: counts lines with ';' that are not inside function bodies (we can't parse),
       but still gives a hint if many globals exist.
    */
    char *p = content;
    char line[1024];
    while (*p) {
        char *nl = strchr(p, '\n');
        size_t len = nl ? (size_t)(nl - p) : strlen(p);
        if (len > sizeof(line)-1) len = sizeof(line)-1;
        memcpy(line, p, len); line[len] = '\0';
        /* trim leading spaces */
        char *t = line;
        while (*t && isspace((unsigned char)*t)) t++;
        if (*t && strchr(t, ';') && !strstr(t, "printf(") && !strstr(t, "return ")) {
            /* crude filter: if line contains '(' then it's probably a function prototype or call */
            if (!strchr(t, '(')) S.globals_suspected++;
        }
        /* detect sig_atomic_t */
        if (strstr(line, "sig_atomic_t")) {
            if (!strstr(line, "extern")) S.sig_atomic_count++;
        }

        /* builtins (heuristique : définition name(... ) or function named ft_xxx ) */
        if (strstr(line, "echo(") || strstr(line, "builtin_echo") || strstr(line, "ft_echo")) S.builtin_echo = 1;
        if (strstr(line, "cd(") || strstr(line, "builtin_cd") || strstr(line, "ft_cd")) S.builtin_cd = 1;
        if (strstr(line, "pwd(") || strstr(line, "builtin_pwd") || strstr(line, "ft_pwd")) S.builtin_pwd = 1;
        if (strstr(line, "export(") || strstr(line, "builtin_export") || strstr(line, "ft_export")) S.builtin_export = 1;
        if (strstr(line, "unset(") || strstr(line, "builtin_unset") || strstr(line, "ft_unset")) S.builtin_unset = 1;
        if (strstr(line, "env(") || strstr(line, "builtin_env") || strstr(line, "ft_env")) S.builtin_env = 1;
        if (strstr(line, "exit(") || strstr(line, "builtin_exit") || strstr(line, "ft_exit")) S.builtin_exit = 1;

        /* syscalls / functions */
        if (strstr(line, "readline(")) S.uses_readline = 1;
        if (strstr(line, "rl_on_new_line") || strstr(line, "rl_replace_line") || strstr(line, "rl_redisplay") || strstr(line, "rl_clear_history") || strstr(line, "add_history(")) S.uses_rl_functions = 1;
        if (strstr(line, "fork(")) S.uses_fork = 1;
        if (strstr(line, "execve(")) S.uses_execve = 1;
        if (strstr(line, "pipe(")) S.uses_pipe = 1;
        if (strstr(line, "dup2(")) S.uses_dup2 = 1;
        if (strstr(line, "waitpid(") || strstr(line, "wait(")) S.uses_waitpid = 1;
        if (strstr(line, "signal(") || strstr(line, "sigaction(")) S.uses_signal = 1;
        if (strstr(line, "getcwd(")) S.uses_getcwd = 1;
        if (strstr(line, "chdir(")) S.uses_chdir = 1;

        /* parsing tokens */
        if (strchr(line, '\'')) S.token_single_quotes = 1;
        if (strchr(line, '"')) S.token_double_quotes = 1;
        if (strchr(line, '$')) S.token_dollar_var = 1;
        if (strstr(line, "$?")) S.token_dollar_qm = 1;
        if (strstr(line, " << ") || strstr(line, "<<")) S.token_heredoc = 1;
        if (strstr(line, " >> ") || strstr(line, ">>")) S.token_redir_append = 1;
        if (strstr(line, " < ") || strstr(line, "<")) S.token_redir_input = 1;
        if (strstr(line, " > ") || strstr(line, ">")) S.token_redir_output = 1;
        if (strchr(line, '|')) S.token_pipe = 1;

        if (!nl) break;
        p = nl + 1;
    }

    free(content);
}

/* Parcours récursif du repo */
static void walk_dir(const char *root) {
    DIR *d = opendir(root);
    if (!d) return;
    struct dirent *ent;
    char path[MAXPATH];
    while ((ent = readdir(d))) {
        if (!strcmp(ent->d_name, ".") || !strcmp(ent->d_name, "..")) continue;
        snprintf(path, sizeof(path), "%s/%s", root, ent->d_name);
        struct stat st;
        if (stat(path, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) {
            walk_dir(path);
        } else if (S_ISREG(st.st_mode)) {
            const char *ext = strrchr(path, '.');
            if (strcmp(ent->d_name, "Makefile") == 0 || strcmp(ent->d_name, "makefile") == 0) {
                inspect_makefile(path);
            }
            if (ext && strcmp(ext, ".h") == 0) inspect_header(path);
            if (ext && (strcmp(ext, ".c") == 0 || strcmp(ext, ".h") == 0)) inspect_source(path);
        }
    }
    closedir(d);
}

/* --- Partie dynamique : exécute un script (potentiellement multi-lignes) dans bash et dans ./minishell et récupère la sortie --- */
static char *run_script_capture(const char *script_content, const char *sh_path) {
    /* écrit le script dans un fichier temporaire */
    char tmpname[] = "/tmp/minishell_checker_script_XXXXXX";
    int fd = mkstemp(tmpname);
    if (fd < 0) return NULL;
    FILE *f = fdopen(fd, "w");
    if (!f) { close(fd); unlink(tmpname); return NULL; }
    fputs(script_content, f);
    fputs("\n", f); /* ensure ending newline */
    fclose(f);

    /* build command: sh_path < tmpname  (redirect stderr to stdout) */
    char cmd[1024];
    snprintf(cmd, sizeof(cmd), "%s < %s 2>&1", sh_path, tmpname);
    FILE *pf = popen(cmd, "r");
    if (!pf) { unlink(tmpname); return NULL; }
    char *out = malloc(BUF);
    if (!out) { pclose(pf); unlink(tmpname); return NULL; }
    size_t r = fread(out, 1, BUF - 1, pf);
    out[r] = '\0';
    pclose(pf);
    unlink(tmpname);
    return out;
}

/* Exécute une série de tests dynamiques et remplit les champs correspondants dans S */
static void dynamic_tests(void) {
    /* ensure minishell exists and is executable */
    if (access("./minishell", X_OK) != 0) {
        printf("\n--- Tests dynamiques SKIPPED : ./minishell absent ou non exécutable ---\n");
        return;
    }

    printf("\n--- Lancement des tests dynamiques (non interactifs) ---\n");

    struct {
        const char *name;
        const char *script;
        int *field_ptr; /* optional: pointer to flag in S to mark success */
    } tests[] = {
        /* builtins */
        { "echo simple", "echo hello", NULL },
        { "echo -n", "echo -n world", NULL },
        { "pwd", "pwd", NULL },
        { "export+echo", "export MYCHK=42\n echo $MYCHK", NULL },
        { "unset", "export XTEST=1\n unset XTEST\n echo $XTEST", NULL },
        { "env", "export ACHK=7\n env | grep -q ACHK && echo OK || echo NOK", NULL },

        /* pipes & redirections */
        { "pipe simple", "printf 'a\nb\nc\n' | wc -l", NULL },
        { "redir out+in", "echo salut > tmp_chk && cat < tmp_chk && rm -f tmp_chk", NULL },
        { "redir append", "echo one > tmp_chk2\n echo two >> tmp_chk2\n cat tmp_chk2\n rm -f tmp_chk2", NULL },

        /* heredoc */
        { "heredoc", "cat <<EOF\nhello-from-heredoc\nEOF", NULL },

        /* quotes */
        { "single quotes", "echo 'a $PATH \" \"' ", NULL },
        { "double quotes + $", "export QCHK=qq\n echo \"$QCHK\" ", NULL },

        /* $? expansion: run a failing command then echo $? */
        { "dollar_qm", "false\n echo $?\n true\n echo $?", NULL },

        /* pipeline complex */
        { "complex pipe", "echo -n 'aa bb' | awk '{print $2}'", NULL }
    };

    size_t n = sizeof(tests)/sizeof(tests[0]);
    for (size_t i = 0; i < n; ++i) {
        char *out_bash = run_script_capture(tests[i].script, "bash");
        char *out_mini = run_script_capture(tests[i].script, "./minishell");
        printf("Test %-20s : ", tests[i].name);
        if (out_bash == NULL || out_mini == NULL) {
            printf("ERREUR (impossible d'exécuter)\n");
        } else {
            /* normalize trailing newlines/spaces for comparison */
            while (strlen(out_bash) && (out_bash[strlen(out_bash)-1] == '\n' || out_bash[strlen(out_bash)-1] == '\r')) out_bash[strlen(out_bash)-1]=0;
            while (strlen(out_mini) && (out_mini[strlen(out_mini)-1] == '\n' || out_mini[strlen(out_mini)-1] == '\r')) out_mini[strlen(out_mini)-1]=0;
            if (strcmp(out_bash, out_mini) == 0) {
                printf("✅\n");
            } else {
                printf("❌\n");
                printf("  bash  -> \"%s\"\n", out_bash[0] ? out_bash : "<empty>");
                printf("  minis -> \"%s\"\n", out_mini[0] ? out_mini : "<empty>");
            }
        }
        free(out_bash); free(out_mini);
    }

    /* Signal behaviour tests (best-effort, non-interactive):
       We'll launch ./minishell in a child process and send SIGINT then SIGQUIT
       and observe if process exits or remains (heuristic). This is tricky:
       interactive behavior differs — here we only check that the shell doesn't exit on SIGINT (expected),
       and that SIGQUIT is ignored (expected).
    */
    printf("\nSignal tests (heuristique, best-effort):\n");
    pid_t pid = fork();
    if (pid == 0) {
        /* child: create new session so signals we send target it */
        setsid();
        /* redirect stdin to /dev/null to run interactive loop safely */
        freopen("/dev/null", "r", stdin);
        execl("./minishell", "./minishell", (char*)NULL);
        _exit(127);
    } else if (pid > 0) {
        sleep(1); /* give time to start */
        /* send SIGINT */
        if (kill(pid, SIGINT) == 0) {
            sleep(1);
            int st;
            pid_t r = waitpid(pid, &st, WNOHANG);
            if (r == 0) {
                printf("  SIGINT : la shell ne s'est pas terminée immédiatement (souhaitable en interactive) -> OK heuristique\n");
            } else {
                printf("  SIGINT : la shell s'est terminée après SIGINT -> ⚠️ (vérifier comportement interactif)\n");
            }
        } else {
            printf("  SIGINT : impossible d'envoyer SIGINT\n");
        }
        /* send SIGQUIT */
        if (kill(pid, SIGQUIT) == 0) {
            sleep(1);
            int st;
            pid_t r = waitpid(pid, &st, WNOHANG);
            if (r == 0) {
                printf("  SIGQUIT : la shell ne s'est pas terminée après SIGQUIT -> OK heuristique (bash ignore) \n");
            } else {
                printf("  SIGQUIT : la shell s'est terminée après SIGQUIT -> ⚠️ (vérifier comportement interactif)\n");
            }
        } else {
            printf("  SIGQUIT : impossible d'envoyer SIGQUIT\n");
        }
        /* cleanup: try to kill it if still alive */
        kill(pid, SIGKILL);
        waitpid(pid, NULL, 0);
    } else {
        printf("  Signal tests : fork() failed\n");
    }
}

/* --- Rapport final : compare avec le sujet et affiche ce qu'il reste à faire --- */
static void print_final_report(void) {
    printf("\n\n========= Rapport détaillé par critère (par rapport au sujet Minishell) =========\n\n");

    /* Makefile */
    printf("Makefile : ");
    if (!S.makefile_present) printf("❌ Makefile absent\n");
    else {
        printf("Présent. Détails:\n");
        printf("  NAME   : %s\n", S.mk_NAME ? "✔️" : "❌");
        printf("  all    : %s\n", S.mk_all ? "✔️" : "❌");
        printf("  clean  : %s\n", S.mk_clean ? "✔️" : "❌");
        printf("  fclean : %s\n", S.mk_fclean ? "✔️" : "❌");
        printf("  re     : %s\n", S.mk_re ? "✔️" : "❌");
        printf("  make -n : %s\n", S.mk_make_n_ok ? "✔️ (règles valides)" : "⚠️ (make -n échoue)");
    }

    /* Headers */
    printf("\nHeaders (.h) : %d trouvés, %d avec include guards\n", S.headers_total, S.headers_with_guards);
    if (S.headers_total > 0 && S.headers_with_guards < S.headers_total) {
        printf("  ⚠️ Quelques headers manquent d'include guards (ajoute #ifndef/#define/#endif)\n");
    }

    /* Globals & signal */
    printf("\nVariables globales (heuristique) :\n");
    printf("  Variables globales suspectées : %d\n", S.globals_suspected);
    printf("  Occurrences non-extern de sig_atomic_t : %d\n", S.sig_atomic_count);
    if (S.sig_atomic_count == 0) {
        printf("  ⚠️ Aucun sig_atomic_t global trouvé : tu dois définir 1 variable globale (sig_atomic_t) pour les signaux.\n");
    } else if (S.sig_atomic_count > 1) {
        printf("  ❌ Trop de sig_atomic_t globaux (doit être au maximum 1). Réduire à une seule variable globale contenant uniquement le numéro du signal.\n");
    } else {
        printf("  ✔️ sig_atomic_t global détecté (vérifie qu'il n'accède pas aux structures principales).\n");
    }
    if (S.globals_suspected > S.sig_atomic_count) {
        printf("  ⚠️ Il semble y avoir d'autres variables globales — le sujet interdit d'exposer des structures globales. Réduire les globals.\n");
    }

    /* Builtins */
    printf("\nBuiltins obligatoires :\n");
    printf("  echo   : %s\n", S.builtin_echo ? "✔️" : "❌");
    printf("  cd     : %s\n", S.builtin_cd ? "✔️" : "❌");
    printf("  pwd    : %s\n", S.builtin_pwd ? "✔️" : "❌");
    printf("  export : %s\n", S.builtin_export ? "✔️" : "❌");
    printf("  unset  : %s\n", S.builtin_unset ? "✔️" : "❌");
    printf("  env    : %s\n", S.builtin_env ? "✔️" : "❌");
    printf("  exit   : %s\n", S.builtin_exit ? "✔️" : "❌");

    /* Functions */
    printf("\nFonctions / syscalls importantes (autorisees) :\n");
    printf("  readline / rl_*  : %s\n", (S.uses_readline || S.uses_rl_functions) ? "✔️" : "❌ (utiliser readline pour l'historique)" );
    printf("  fork             : %s\n", S.uses_fork ? "✔️" : "❌");
    printf("  execve           : %s\n", S.uses_execve ? "✔️" : "❌");
    printf("  pipe             : %s\n", S.uses_pipe ? "✔️" : "❌");
    printf("  dup2             : %s\n", S.uses_dup2 ? "✔️" : "❌");
    printf("  waitpid/wait     : %s\n", S.uses_waitpid ? "✔️" : "❌");
    printf("  signal/sigaction : %s\n", S.uses_signal ? "✔️" : "❌");
    printf("  getcwd / chdir   : %s / %s\n", S.uses_getcwd ? "✔️" : "❌", S.uses_chdir ? "✔️" : "❌");

    /* Parsing */
    printf("\nParsing : tokens détectés (heuristique)\n");
    printf("  Simple quotes (') : %s\n", S.token_single_quotes ? "✔️" : "❌");
    printf("  Double quotes (\") : %s\n", S.token_double_quotes ? "✔️" : "❌");
    printf("  Expansion $VAR     : %s\n", S.token_dollar_var ? "✔️" : "❌");
    printf("  Expansion $?       : %s\n", S.token_dollar_qm ? "✔️" : "❌");
    printf("  Redirection <      : %s\n", S.token_redir_input ? "✔️" : "❌");
    printf("  Redirection >      : %s\n", S.token_redir_output ? "✔️" : "❌");
    printf("  Redirection >>     : %s\n", S.token_redir_append ? "✔️" : "❌");
    printf("  Heredoc <<         : %s\n", S.token_heredoc ? "✔️" : "❌");
    printf("  Pipe |             : %s\n", S.token_pipe ? "✔️" : "❌");

    /* Recommendations (automatique) */
    printf("\n\n--- Recommandations automatiques ---\n");
    if (!S.makefile_present) printf(" - Ajouter un Makefile avec les targets obligatoires (NAME, all, clean, fclean, re).\n");
    if (!S.mk_make_n_ok) printf(" - Corriger le Makefile (make -n échoue).\n");
    if (S.headers_total > 0 && S.headers_with_guards < S.headers_total) printf(" - Ajouter include guards dans les headers manquants.\n");
    if (S.sig_atomic_count == 0) printf(" - Déclarer une variable globale `volatile sig_atomic_t g_sig` (ou similaire) contenant seulement le numéro du signal.\n");
    if (S.sig_atomic_count > 1) printf(" - Ne garder qu'une seule variable globale sig_atomic_t.\n");

    if (!S.builtin_echo || !S.builtin_cd || !S.builtin_pwd || !S.builtin_export || !S.builtin_unset || !S.builtin_env || !S.builtin_exit) {
        printf(" - Implementer les builtins manquants listés ci-dessus.\n");
    }

    if (!S.uses_readline && !S.uses_rl_functions) printf(" - Utiliser readline() + add_history pour l'historique (requis).\n");
    if (!S.uses_fork || !S.uses_execve) printf(" - Implémenter fork + execve pour lancer des executables.\n");
    if (!S.uses_pipe || !S.uses_dup2) printf(" - Implémenter pipeline via pipe() et redirection fd avec dup2().\n");
    if (!S.token_heredoc) printf(" - Implémenter heredoc (<<) conformément au sujet (ne pas stocker heredoc dans history).\n");
    if (!S.token_double_quotes) printf(" - Implémenter les double quotes (expansions $ autorisées dedans).\n");
    if (!S.token_dollar_qm) printf(" - Implémenter l'expansion de $? (statut de la dernière pipeline foreground).\n");

    printf("\nNote finale : Ce checker combine analyse statique heuristique et tests dynamiques simples.\nIl te donne un plan clair de ce qu'il reste à coder par rapport au sujet. Pour valider complètement, écris\nune suite de tests d'intégration qui automatise les scénarios utilisateurs et vérifie la mémoire (valgrind) et\nles cas limites (quotes imbriquées, pipes + redirections, erreurs système).\n\n=============================================================================\n");
}

/* --- Main --- */
int main(void) {
    memset(&S, 0, sizeof(S));
    char cwd[MAXPATH];
    if (!getcwd(cwd, sizeof(cwd))) {
        fprintf(stderr, "Erreur getcwd: %s\n", strerror(errno));
        return 1;
    }
    printf("Minishell full checker — répertoire: %s\n", cwd);

    walk_dir(".");

    /* If Makefile not found via walk, also check current dir Makefile name variations */
    if (!S.makefile_present) {
        if (access("Makefile", R_OK) == 0 || access("makefile", R_OK) == 0) {
            S.makefile_present = 1;
            inspect_makefile("Makefile");
        }
    }

    /* Print quick summary static */
    printf("\nAnalyse statique terminée. Résumé rapide:\n");
    printf(" - Makefile present : %s\n", S.makefile_present ? "Oui" : "Non");
    printf(" - Headers trouvés  : %d, guards : %d\n", S.headers_total, S.headers_with_guards);
    printf(" - suspect globals  : %d, sig_atomic occurrences : %d\n", S.globals_suspected, S.sig_atomic_count);

    /* Lancer tests dynamiques */
    dynamic_tests();

    /* Rapport détaillé */
    print_final_report();

    return 0;
}
